</section>
<!-- Required Jquery -->
<script type="text/javascript" src="<?= base_url('assets/') ?>js/jquery/jquery.min.js "></script>
<script type="text/javascript" src="<?= base_url('assets/') ?>js/jquery-ui/jquery-ui.min.js "></script>
<script type="text/javascript" src="<?= base_url('assets/') ?>js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/') ?>js/bootstrap/js/bootstrap.min.js "></script>
<!-- waves js -->
<script src="<?= base_url('assets/') ?>pages/waves/js/waves.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?= base_url('assets/') ?>js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- notification js -->
<script type="text/javascript" src="<?= base_url('assets/') ?>js/bootstrap-growl.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/') ?>pages/notification/notification.js"></script>
<script src="<?= base_url('assets/') ?>js/pcoded.min.js"></script>
<script src="<?= base_url('assets/') ?>js/vertical/vertical-layout.min.js"></script>
<script src="<?= base_url('assets/') ?>js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="<?= base_url('assets/') ?>js/script.js"></script>

</body>

</html>